
void APP_LEDUpdateUSBStatus(void);
