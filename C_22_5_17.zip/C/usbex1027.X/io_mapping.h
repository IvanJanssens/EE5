
#include "system.h"

#define LED_USB_DEVICE_STATE                    LED_D1

//#define BUTTON_DEVICE_CDC_BASIC_DEMO            BUTTON_S2
